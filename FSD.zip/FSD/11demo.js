var a=require('./10demo.js');
console.log(a);