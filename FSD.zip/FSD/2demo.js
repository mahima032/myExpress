var a=10;
let b=20;
console.log(`A value is ${a}`);
console.log(`B value is ${b}`);
if(true)
{
    var a=100;
let b=200;
console.log(`A value is ${a}`);
console.log(`B value is ${b}`);

}
console.log(`A value is ${a}`);
console.log(`B value is ${b}`);




