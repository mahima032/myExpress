var userdata={
    name:"mahima",
    gender:"female"
}
console.log("My name is "+userdata.name);
console.log("My gender is "+ userdata['gender']);
userdata.m=456789;
console.log("My mobile is"+userdata['mobile']);
userdata.mobile=123;
console.log("My mobile is"+userdata['mobile']);
console.log('name' in userdata);
delete userdata.mobile;
console.log(userdata['mobile']);
console.log(userdata.mobile);
console.log(userdata);
var a=JSON.stringify(userdata);
console.log(a);
console.log(JSON.parse(a));
console.log(Object.keys(userdata));



