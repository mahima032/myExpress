class Car{
    constructor(color,model)
    {
        this.color=color;
        this.model=model;
    }
    getColor()
    {
        console.log("Color is "+this.color);
        
    }
    getModel()
    {
        console.log("Model is "+this.model);

    }
}
var a=new Car("white",2023);
a.getColor();
a.getModel();


