let demo=()=>console.log("Demo");
demo();
let demo1=(x)=>console.log("Demo"+x);
demo1("hi");
let demo2=(x,y)=>x+y;
var ans=demo2(10,20);
console.log(ans);
let demo3=(x)=>{
    
}





