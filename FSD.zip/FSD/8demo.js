// var http=require('http');
// var fs=require('fs');
// http.createServer(function(req,res){
//     fs.readFile(__dirname+'/demo.html','utf8',function(err,data)
//     {
//         console.log(data);
//         res.write(data);
//         res.end("hello")
//     });
// }).listen(3000);
// console.log("server is on port 3000");


var http=require('http');
var fs=require('fs')
http.createServer(function(req,res)
    {
      fs.readFile(__dirname+'/index.html','utf-8',function(req,res){
        console.log(data);
        res.write(data);
        res.end('ji')
      });
    }).listen(3000);
    console.log('ki');