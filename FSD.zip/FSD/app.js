const express=require('express')
const app=express()
const port =5000
//middleware to load data
app.use(express.static(__dirname+'/public'));
//custom middleware
app.use(function(req,res,next){
console.log('middleware called'+req.url);
next();
})
app.get('/',(req,res)=>{
    res.send('hello')
})
app.get('/home',(req,res)=>{
    res.sendFile(__dirname+'/home.html');
})
app.get('/about',(req,res)=>{
    res.sendFile(__dirname+'/about.html');
})
app.get('/cake/ahemdabad',(req,res)=>{
    res.send('ahemdabad');
})
//http://localhost:5000/contact/78
app.get('/contact/:id',(req,res)=>{
    var id=req.params.id;
    res.send("contact "+id);
})
//route with query string
//http://localhost:5000/search?name=acc
app.get('/search/',(req,res)=>{
    var id=req.query.name;
    res.send("Search is "+id);
})
//http://localhost:5000/myform
app.get('/contact',(req,res)=>{
    res.sendFile(__dirname+'/form.html');
})
app.get('/process/',(req,res)=>{
    var a=parseInt(req.query.t1);
    var b=parseInt(req.query.t2);
    var d=parseInt(req.query.t3);
    var e=parseInt(req.query.t4);
    var c=(a+b+d+e);
    var f=(c/4);
    var p=(c*100)/40;
    if(p>70)
    {
        d='pass with distinction'
    }
    else if(p<70 && p>33)
    {
        d='pass '
    }
    else if(p<33){
        d='fail'
    }
    var ans=` Sub1 marks is ${a} <br/> Sub1 marks is  ${b} <br/> Sub3 marks is ${d} <br/> Sub4 marks is ${e} <br/> ans is ${c} <br/>avg is ${f} <br/> result is ${p} and ${d}`;
    res.send(ans);
})
app.listen(port,()=>{
console.log(`example ${port}`)
})



