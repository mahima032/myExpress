var a=10;
var b=20;
console.log("A value is :"+a);
console.log(`A value is ${a} B value is ${b} 'a " a
sum is ${a+b}`);

