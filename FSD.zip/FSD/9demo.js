// var http=require('http');
// var fs=require('fs');
// http.createServer(function(req,res){
//   fs.writeFile('test.html','hi',function(err)
//   {
//     if(err) throw err;
//     console.log('file created');
//   });
//   fs.readFile(__dirname+'/test.html','utf8',function(err,data)
//     {
//         console.log(data);
//         res.write(data);
//         res.end("hello")
//     });
//     fs.unlink(__dirname+'/test.html',function(err)
//     {
//         if(err) throw err;
//         console.log('file deleted');
//     })
// }).listen(3000);
// console.log("server is on port 3000");




// var http=require('http')
// var fs=require('fs')
// http.createServer(function(req,res){
//   fs.writeFile('test.html','hi',function(err){
//     if(err) console.log("err")
//     else{
//     console.log("created");
  
//   fs.readFile(__dirname+'/test.html','utf-8',function(err,data){
//     if(err) console.log("err")
//     else{
//     console.log(data);
//     res.write(data);
//     res.end("ki");


  
// fs.unlink('test.html',function(err){
//   if(err) console.log(err)
//   console.log("read");
// });
//   }
// });
// }
// });
// }).listen(3000);

const http = require('http');
const fs = require('fs').promises; // Use the promises version of fs

http.createServer(async function (req, res) {
  try {
    // Write data to the file
    await fs.writeFile('test.html', 'hi');
    console.log("created");

    // Read data from the file
    const data = await fs.readFile(__dirname + '/test.html', 'utf-8');
    console.log(data);

    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(data);
    res.end("ki");

    // Delete the file after reading and responding
    await fs.unlink('test.html');
    console.log("read");
  } catch (err) {
    console.log(err);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('Error occurred');
  }
}).listen(3000);

