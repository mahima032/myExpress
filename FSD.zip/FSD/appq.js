import {sum} from './sum.js';
var ans=sum(10,20);
console.log(ans);