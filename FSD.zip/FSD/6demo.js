class Person{
    constructor(name)
    {
        this.name=name;
    }
    greet()
    {
        console.log(`Hello ${this.name}`);
    }
}
class Student extends Person{
    constructor(name)
    {
        console.log("student class");
        super(name);
    }
}
let a=new Student("Mahima");
a.greet();


