function demo(...a)
{
    console.log(a);
}
demo(10,20,30,40);

