function college(uni){
    this.uni=uni;
    this.i="'cspit";
    this.d='cse';
}
var inquiry=new college("charusat");
for(var  uni in inquiry)
{
    console.log(inquiry(uni));
}