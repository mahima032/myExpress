console.log("Hello")
a=10
b=20
s=a+b
console.log(s)